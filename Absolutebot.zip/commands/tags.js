
module.exports=async function tag (msg, char){
  const tags = ['?bayo','?davus','?dizzy','?dj','?ewsa',"?gomla",'?ilordie','?isaki','?kong','?kuro','?laphy','?lc','?lian','?master','?parkiet','?penelkata','?vic','?yahiko','?ynn','?yusuke',]
  if(tags.includes(char)){
    msg.channel.send({ files: [`./tags/${char}.png`] })
  }

}