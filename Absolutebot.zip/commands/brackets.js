module.exports= async function(msg,char){
  let result = char.indexOf("?bracket");
 
  if(result==0){
     let text = char.replace(/\s+/g, ' ').trim()
    const chars = text.split(" ")
   chars.shift()
    shuffleArray(chars)
  
    
   for (let i = 0; i < chars.length; i=i+2) {
     if (i+1 >= chars.length ){
       msg.channel.send(`${chars[i]} X BYE`)
     }
     else{
       msg.channel.send(`${chars[i]} X ${chars[i+1]}`)
     }
  
}
    
  }

//randomise 

function shuffleArray(array) {
    for (var i = array.length - 1; i > 0; i--) {
        var j = Math.floor(Math.random() * (i + 1));
        var temp = array[i];
        array[i] = array[j];
        array[j] = temp;
    }
}




//   function seeding(numPlayers){
//   var rounds = Math.log(numPlayers)/Math.log(2)-1;
//   var pls = [1,2];
//   for(var i=0;i<rounds;i++){
//     pls = nextLayer(pls);
//   }
//   return pls;
//   function nextLayer(pls){
//     var out=[];
//     var length = pls.length*2+1;
//     pls.forEach(function(d){
//       out.push(d);
//       out.push(length-d);
//     });
//     return out;
//   }
// }
}