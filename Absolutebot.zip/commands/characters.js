//pages
const page1 =['naruto','sakura', 'sasuke','shikamaru','ino','chouji','kiba','hinata','shino','lee','tenten','neji','gaara','temari','kankuro','dosu','kin','zaku','yk','obito','rin']

const page2 = ['anbu kakashi','anko','drunken lee','hanabi','hayate','iruka','jiroubou','kakashi','kidoumaru','kimimaro','misumi','mizuki','oboro','rehab gaara','sakon','shigure','shiore','shizune','tayuya','yoroi','young kushina']



//pages
//page1
 /* if(page1.includes(char)){
    msg.channel.send({ files: [`./page1/${char}.png`] })
  }*/
  //page2
    /*if(page2.includes(char)){
    msg.channel.send({ files: [`./page2/${char}.png`] })
  }*/