
const fs = require('fs');
const counter = './counter' 



module.exports=function (msg,char) { 

  if (char==='?counter'){
    fs.readdir(counter, (err, files) => {      
msg.channel.send({files:[`./counter/${files[Math.floor(Math.random() * files.length)]}`]})
     })
    
  }
  if(char==='?counterlist'){
  
    fs.readdir(counter, (err, files) => {
          
      msg.channel.send(`there are ${files.length} embarrassing counters available`)
     })
 
    
 }
  
} 



  