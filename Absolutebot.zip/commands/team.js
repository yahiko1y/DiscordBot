
const fs = require('fs');
const jimp = require('jimp')
const dir1 = './chars1';
const dir2 = './chars2';
const dir0 = './chars0';
const chars =[]


module.exports= async function(msg){
  const roles=msg.member._roles 
      if(msg.channel.id!='940284168225583214'){
        return;
      }
      if (!(roles.includes("628635220010336267")) &&!(roles.includes("628634700990382083"))&& !(roles.includes("634047810198831104"))&&!(roles.includes("671792816325787668"))  ) {

   return
 }
    
  {
   for (let i = 0; i < 3; i++) {
      const dir_num= Math.floor(Math.random() * 3)
      if(dir_num===0){
        fs.readdir(dir0, (err, files) => {
          const img = `./chars0/${files[Math.floor(Math.random() * files.length)]}`
          chars.push(img)
     })
        
      }
       if(dir_num===1){
        fs.readdir(dir1, (err, files) => {
          chars.push(`./chars1/${files[Math.floor(Math.random() * files.length)]}`)

     })
  
      }
       if(dir_num===2){
        fs.readdir(dir2, (err, files) => {
          chars.push(`./chars2/${files[Math.floor(Math.random() * files.length)]}`)

     })
       
      }
      
   }
console.log(chars)
   async function CreateTeam(target) {
    
  let mask = await jimp.read('./temp/team.png')


  let fundo = await jimp.read(target[0])
  mask.composite(fundo, 25, 30).write('na.png')

  let fundo1 = await jimp.read(target[1])
  mask.composite(fundo1, 105, 30).write('na.png')

  let fundo2 = await jimp.read(target[2])
  mask.composite(fundo2, 185, 30).write('na.png')



  }

 CreateTeam(chars)

 while(chars.length > 0) {
    chars.pop();
}
console.log(chars)
 msg.channel.send({files:['na.png']})
}
  
}