
const fs = require('fs');
const meme = './memes' 



module.exports=function (msg,char) { 
   const roles=msg.member._roles
     if (!(roles.includes("628635220010336267")) &&!(roles.includes("628634700990382083"))&& !(roles.includes("634047810198831104"))&&!(roles.includes("671792816325787668"))  ) {

   return
 }
 
  if (char==='?meme' & msg.channel.id==='628637230973583373' ){
    
    fs.readdir(meme, (err, files) => {      
msg.channel.send({files:[`./memes/${files[Math.floor(Math.random() * files.length)]}`]})
     })
    
    
  }
  if(char==='?memelist'){
  
    fs.readdir(meme, (err, files) => {
          
      msg.channel.send(`there are ${files.length} memes available`)
     })
 
    
 }
  
} 



  