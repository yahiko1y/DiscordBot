module.exports=function (msg, char) {


   if(char==='lahiko'){
    msg.channel.send('notice me senpai')

  }
  if(char==='revolution'){
    msg.channel.send('you son of bitch i am in')

  }
  if(char==='?thread'){
    msg.channel.send('https://naruto-boards.net/viewtopic.php?f=82&t=14725')

  }
  if(char==='?recruitment'){
    msg.channel.send('https://naruto-boards.net/viewtopic.php?f=81&t=14728')

  }
   /*if(char.includes('<@&663095970661138443>')){
    msg.channel.send('https://imgflip.com/i/5td603')}*/

   /*if (msg.author.id === "228335067720581120") {
    console.log(char)};*/
} 