

module.exports= async function(msg){
  msg.channel.send(`
?team - gives a random tea,
?teams - gives you a matchup of 2 random teams
?meme - gives you a random meme
?memelist - gives you number of available memes
?member name - gives player card of that member (?yahiko)
?brackets -  gives a random bracket of the people u mentionned after it
revolution - join us in the revlution to dethrown adlof dizzy
lahiko - dont you dare :seeU:`)
  
}