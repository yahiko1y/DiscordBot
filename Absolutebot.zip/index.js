const Discord = require('discord.js')
const client = new Discord.Client({intents:["GUILDS", "GUILD_MESSAGES"]})
const alive = require('./server')

client.on('ready',() => {
  console.log(`logged in as ${client.user.tag}`)
  client.user.setActivity('?help, also trying to find isaki', { type: 'PLAYING' })
})

const tags = require('./commands/tags')
const meme = require('./commands/meme')
const counter = require('./commands/counter')
const teams = require('./commands/teams')
const help = require('./commands/help')
const words = require('./commands/words')
const brackets = require('./commands/brackets')
const team = require('./commands/team')
client.on("message", msg=> {
  let char=(msg.content).toLowerCase()
  if(msg.author.id === client.user.id) return;
  
  try {
     words(msg, char) 
   } catch (error) {
     console.log('something wrong with words')
   }
  
  
  try {
     brackets(msg, char)
   } catch (error) {
     console.log('something wrong with bbrackets')
   }
  
    try {
     tags(msg, char)
   } catch (error) {
     console.log('something wrong with tags')
   } 

try {
       meme(msg, char)
   } catch (error) {
     console.log('something wrong with memes')
   }
  
  try {
     counter(msg, char) 
   } catch (error) {
     console.log('something wrong with counters')
   }

   if(char==='?teams'){
   try {
     teams(msg)
   } catch (error) {
     console.log('something wrong with teamss')
   }
  } 

   if(char==='?team'){
   try {
     team(msg)
   } catch (error) {
     console.log('something wrong with team')
   }
  } 


   if(char==='?help'){
   try {
     help(msg)
   } catch (error) {
     console.log('something wrong with help')
   }
  }
  
})
 



// msg.channel.send({ files: [`./page1/${char}.png`] })

const token = process.env['abso']
alive()
client.login(token)