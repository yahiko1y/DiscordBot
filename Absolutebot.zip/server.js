const express= require('express')
const server= express()

server.all('/',(req,res)=>{
  res.send("bot is running")
})

function alive(){
  server.listen(3000,()=>{
    console.log("server is ready")
  })
}
module.exports= alive